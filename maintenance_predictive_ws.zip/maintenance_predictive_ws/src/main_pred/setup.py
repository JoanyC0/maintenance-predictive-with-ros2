from setuptools import find_packages, setup

package_name = 'main_pred'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=[   
        'setuptools',
        'tensorflow',
        'numpy',
        'opencv-python',
        'matplotlib',
        'seaborn',
        'scikit-learn',
],
    zip_safe=True,
    maintainer='jacquescormery',
    maintainer_email='jacquescormery@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'obd = main_pred.obd_node:main',
            'model_predictive = main_pred.model_subscriber:main',
            'analyzer = main_pred.hi_analyzer_node:main',
            'obd_test = main_pred.obd_test:main',

         
        ],
    },
)
