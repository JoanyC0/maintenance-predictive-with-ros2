import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np
import csv
import os
import matplotlib.pyplot as plt
import seaborn as sns

class HIMetricsNode(Node):
    def __init__(self):
        super().__init__('hi_metrics_node')

        self.actual_hi = None
        self.predicted_hi = None

        self.y_true = []
        self.y_pred = []

        self.all_y_true = []
        self.all_y_pred = []

        self.loss_values = []  # Pour stocker les pertes (erreur absolue moyenne) toutes les 50 prédictions
        self.eval_count = 0  # Compteur d'évaluations (pour la courbe)

        # Création des répertoires et fichiers
        os.makedirs('analyses', exist_ok=True)
        self.csv_file = 'analyses/metrics_stream.csv'
        self.report_file = 'analyses/metrics_report.log'
        self.loss_plot_file = 'analyses/loss_curve.png'

        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['GroundTruth', 'Predicted'])

        # Abonnements ROS 2
        self.subscription_actual = self.create_subscription(
            Float64,
            'hi_actual_topic',
            self.actual_callback,
            10)

        self.subscription_pred = self.create_subscription(
            Float64,
            'hi_predit_topic',
            self.predicted_callback,
            10)

        self.get_logger().info('📊 HI metrics node started.')

    def hi_to_class(self, hi):
        """Convertit un Health Index en classe (Fault, Degraded, Healthy)."""
        if hi < 0.25:
            return 0  # Fault
        elif hi < 0.75:
            return 1  # Degraded
        else:
            return 2  # Healthy

    def actual_callback(self, msg):
        self.actual_hi = msg.data
        self.try_evaluate()

    def predicted_callback(self, msg):
        self.predicted_hi = msg.data
        self.try_evaluate()

    def try_evaluate(self):
        if self.actual_hi is not None and self.predicted_hi is not None:
            true_class = self.hi_to_class(self.actual_hi)
            pred_class = self.hi_to_class(self.predicted_hi)

            self.y_true.append(true_class)
            self.y_pred.append(pred_class)
            self.all_y_true.append(true_class)
            self.all_y_pred.append(pred_class)

            self.get_logger().info(f'🔍 GT: {true_class} | Pred: {pred_class}')

            # Ajout au CSV
            try:
                with open(self.csv_file, 'a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([true_class, pred_class])
            except Exception as e:
                self.get_logger().error(f'❌ Erreur écriture CSV: {str(e)}')

            # Réinitialise pour la prochaine paire
            self.actual_hi = None
            self.predicted_hi = None

            # Évalue toutes les 50 paires
            if len(self.y_true) >= 50:
                self.evaluate()
                self.y_true.clear()
                self.y_pred.clear()

    def evaluate(self):
        self.eval_count += 1
        self.get_logger().info('📈 Evaluation après 50 prédictions :\n')

        report = classification_report(
            self.y_true,
            self.y_pred,
            labels=[0, 1, 2],
            target_names=['Fault', 'Degraded', 'Healthy'],
            digits=3
        )
        self.get_logger().info('\n' + report)

        cm = confusion_matrix(self.y_true, self.y_pred, labels=[0, 1, 2])
        self.get_logger().info(f'📊 Matrice de confusion :\n{cm}')

        # Calcul simple de "perte" : erreur absolue moyenne entre classes (façon loss)
        abs_errors = [abs(t - p) for t, p in zip(self.y_true, self.y_pred)]
        loss = np.mean(abs_errors)
        self.loss_values.append(loss)
        self.get_logger().info(f'📉 Loss moyenne (erreur absolue) sur dernier batch: {loss:.3f}')

        # Enregistrement dans le fichier texte
        try:
            with open(self.report_file, 'a') as f:
                f.write(f'--- Evaluation après 50 prédictions n°{self.eval_count} ---\n')
                f.write(report)
                f.write('\nConfusion matrix:\n')
                f.write(np.array2string(cm))
                f.write(f'\nLoss: {loss:.3f}\n\n')
        except Exception as e:
            self.get_logger().error(f'❌ Erreur écriture log: {str(e)}')

        # 🔥 Heatmap seaborn
        try:
            plt.figure(figsize=(6, 4))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                        xticklabels=['Fault', 'Degraded', 'Healthy'],
                        yticklabels=['Fault', 'Degraded', 'Healthy'],
                        linewidths=0.5, linecolor='black')
            plt.xlabel('Predicted')
            plt.ylabel('Actual')
            plt.title('Confusion Matrix (Last 50 Samples)')
            plt.tight_layout()
            plot_path = 'analyses/confusion_matrix_latest.png'
            plt.savefig(plot_path)
            plt.close()
            self.get_logger().info(f'📉 Heatmap enregistrée dans {plot_path}')
        except Exception as e:
            self.get_logger().error(f'❌ Erreur lors de la sauvegarde du graphique : {str(e)}')

        # 🔥 Mise à jour de la courbe de perte
        try:
            plt.figure(figsize=(6, 4))
            plt.plot(range(1, len(self.loss_values)+1), self.loss_values, marker='o', color='red')
            plt.xlabel('Batch number (50 samples)')
            plt.ylabel('Mean Absolute Error')
            plt.title('Loss Curve (MAE per batch)')
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(self.loss_plot_file)
            plt.close()
            self.get_logger().info(f'📈 Courbe de perte mise à jour dans {self.loss_plot_file}')
        except Exception as e:
            self.get_logger().error(f'❌ Erreur lors de la sauvegarde de la courbe de perte : {str(e)}')

    def finalize(self):
        self.get_logger().info('🧮 Évaluation finale sur l’ensemble du dataset :')

        report = classification_report(
            self.all_y_true,
            self.all_y_pred,
            labels=[0, 1, 2],
            target_names=['Fault', 'Degraded', 'Healthy'],
            digits=3
        )
        self.get_logger().info('\n' + report)

        cm = confusion_matrix(self.all_y_true, self.all_y_pred, labels=[0, 1, 2])
        self.get_logger().info(f'📊 Matrice de confusion finale :\n{cm}')

        try:
            with open(self.report_file, 'a') as f:
                f.write('=== Évaluation finale sur tout le dataset ===\n')
                f.write(report)
                f.write('\nConfusion matrix:\n')
                f.write(np.array2string(cm))
                f.write('\n\n')
        except Exception as e:
            self.get_logger().error(f'❌ Erreur écriture log final: {str(e)}')

def main(args=None):
    rclpy.init(args=args)
    node = HIMetricsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('🛑 Arrêt demandé par l’utilisateur.')
        node.finalize()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

