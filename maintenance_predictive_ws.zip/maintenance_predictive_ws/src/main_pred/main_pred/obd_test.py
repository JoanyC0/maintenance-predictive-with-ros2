import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import numpy as np
import signal
import sys

class OBDSimulatorNode(Node):
    def __init__(self):
        super().__init__('obd_simulator_node')

        self.window_size = 20
        self.last_published_index = 0
        self.num_params = 17

        # Publisher ROS
        self.data_pub = self.create_publisher(Float64MultiArray, 'obd_data', 10)
        self.sim_data = []

        # Timer pour publier chaque seconde
        self.create_timer(1.0, self.publish_window)
        signal.signal(signal.SIGINT, self.cleanup_and_exit)
        self.get_logger().info("✅ Simulation OBD-II continue lancée...")

        # Ranges précis par état et paramètre
        self.state_ranges = {
            0: [  # bon fonctionnement
                (0.7369255150554676, 0.7427363972530375),
                (0.5270429474135161, 0.7024740280604048),
                (0.3833333333333333, 0.5666666666666667),
                (0.0526315648199443, 0.3289473556180745),
                (0.1952191279987618, 0.5458167331891557),
                (0.8857142857142857, 0.8999999999999999),
                (0.5384615384615385, 0.7692307692307693),
                (0.55, 0.775),
                (0.0240963855421686, 0.5662650602409639),
                (0.3596491316366573, 0.5614034510849502),
                (0.0, 0.0),
                (1.0, 1.0),
                (0.7096774193548387, 0.7096774193548387),
                (0.1764705882352941, 0.9019607843137254),
                (0.8822608517671082, 0.8899130672196592),
                (0.8349298158390295, 0.8380485371439138),
                (0.8228809407153359, 0.8373346398824104)
            ],
            1: [  # A surveiller
                (0.1695721077654516, 0.1764395139989434),
                (0.2984898789761165, 0.3044875227589161),
                (0.0, 0.0),
                (0.013157899593144, 0.013157899593144),
                (0.2709163238948589, 0.2749003889755719),
                (0.6428571428571428, 0.657142857142857),
                (0.0769230769230769, 0.3846153846153846),
                (0.65, 0.875),
                (0.0963855421686747, 0.108433734939759),
                (0.6315789355955681, 0.6315789355955681),
                (0.0, 0.0),
                (0.0, 0.0),
                (0.2903225806451612, 0.3225806451612902),
                (0.3529411764705882, 0.4117647058823529),
                (0.6353043364703217, 0.6384347503017022),
                (0.4154600293363332, 0.4205836381350695),
                (0.9042136207741304, 0.9042136207741304)
            ],
            2: [  # moteur en panne
                (0.1516111991547807, 0.1600633914421553),
                (0.2988111813216236, 0.3038449180679018),
                (0.0, 0.0),
                (0.013157899593144, 0.0263157991862882),
                (0.2749003889755719, 0.2749003889755719),
                (0.6142857142857143, 0.6285714285714286),
                (1.0, 1.0),
                (0.4, 0.55),
                (0.0963855421686747, 0.1204819277108434),
                (0.6315789355955681, 0.6315789355955681),
                (0.0, 0.0),
                (0.0, 0.0),
                (0.2903225806451612, 0.2903225806451612),
                (0.3529411764705882, 0.4117647058823529),
                (0.6433043466964083, 0.6486956613383741),
                (0.4014257166343252, 0.4085542463419281),
                (0.8993140617344437, 0.9042136207741304)
            ]
        }

        self.state_labels = {0: "bon fonctionnement", 1: "à surveiller", 2: "moteur en panne"}
        self.current_state = 0
        self.row_counter = 0

    def get_dynamic_probabilities(self):
        """Renvoie les probabilités d'état dynamiques en fonction du nombre de lignes générées."""
        if self.row_counter < 500:
            # Phase 1 : 80% bon fonctionnement, 10% surveiller, 10% panne
            return [0.6, 0.4, 0]
        elif self.row_counter < 1000:
            # Phase 2 : 20% bon fonctionnement, 70% surveiller, 10% panne
            return [0.15, 0.65, 0.2]
        else:
            # Phase 3 : 5% bon fonctionnement, 10% surveiller, 85% panne
            return [0, 0.15, 0.85]

    def generate_row(self):
        """Génère une ligne simulée avec probabilité dynamique selon l'index."""
        probs = self.get_dynamic_probabilities()
        state = np.random.choice([0, 1, 2], p=probs)
        row = [np.random.uniform(low, high) for (low, high) in self.state_ranges[state]]
        self.current_state = state
        self.row_counter += 1
        return row

    def publish_window(self):
        self.sim_data.append(self.generate_row())
        if len(self.sim_data) >= self.window_size:
            start = self.last_published_index
            end = start + self.window_size
            window = self.sim_data[start:end]

            msg = Float64MultiArray()
            msg.data = np.array(window).flatten().tolist()
            self.data_pub.publish(msg)

            self.get_logger().info(
                f"📤 Fenêtre publiée : {start}→{end}, état={self.state_labels[self.current_state]}"
            )

            self.last_published_index += 1

    def cleanup_and_exit(self, signum=None, frame=None):
        self.get_logger().info("Arrêt demandé → obd_simulator_node terminé")
        sys.exit(0)


def main(args=None):
    rclpy.init(args=args)
    node = OBDSimulatorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.cleanup_and_exit()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

