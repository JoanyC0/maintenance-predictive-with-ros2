import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import numpy as np

class HISimulationNode(Node):
    def __init__(self):
        super().__init__('hi_simulation_node')

        self.t = 0
        self.start_hi = 1.0
        self.final_hi = 0.01

        dataset_size = 3486
        window_size = 20
        self.nb_predictions = dataset_size - window_size + 1  # glissement d'une ligne

        # Dégradation exponentielle
        self.lambda_decay = -np.log(self.final_hi / self.start_hi) / self.nb_predictions

        # Subscription au topic 'model_done'
        self.subscription_done = self.create_subscription(
            Bool,
            'model_done',
            self.done_callback,
            10
        )

        # Publisher pour le HI simulé
        self.publisher_hi = self.create_publisher(
            Float64,
            'hi_simulation_topic',
            10
        )

        # Publication initiale de HI = 1.0
        msg_init = Float64()
        msg_init.data = self.start_hi
        self.publisher_hi.publish(msg_init)
        self.get_logger().info(f"📢 HI initial publié : {msg_init.data:.3f}")

        self.get_logger().info(
            f"🚀 HISimulationNode démarré (lambda={self.lambda_decay:.8f}, "
            f"{self.nb_predictions} étapes, HI final={self.final_hi})"
        )

    def done_callback(self, msg: Bool):
        if msg.data:
            # Calculer HI et publier
            hi_real = self.simulate_hi()
            msg_pub = Float64()
            msg_pub.data = hi_real
            self.publisher_hi.publish(msg_pub)
            self.get_logger().info(f"📢 HI simulé publié : {hi_real:.3f}")

            # Incrémenter après publication
            self.t += 1

    def simulate_hi(self):
        # Dégradation exponentielle
        hi = self.start_hi * np.exp(-self.lambda_decay * self.t)
        # Ne pas descendre en dessous de final_hi
        return max(hi, self.final_hi)


def main(args=None):
    rclpy.init(args=args)
    node = HISimulationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

