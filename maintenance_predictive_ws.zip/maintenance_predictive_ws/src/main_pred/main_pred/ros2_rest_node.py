import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import gradio as gr
import threading
import plotly.graph_objects as go
from scipy.ndimage import gaussian_filter1d
import time

# -------- Config par défaut --------
HI_THRESHOLD_DEFAULT = 0.1
WARNING_LEVEL_DEFAULT = 0.5

class ROS2InteractiveDashboard(Node):
    def __init__(self):
        super().__init__('ros2_interactive_dashboard')
        
        # Données
        self.hi_predicted = None
        self.rul_predicted = None
        self.rul_estimate = None
        self.alert_status = False
        self.immediate_alert = False
        self.pred_hi = []
        self.timestamps = []
        self.time = 0
        self.logs = []

        # Configuration du temps
        self.total_days = 30
        self.time_per_window = self.total_days / 2466  # fraction de jour par point
        self.times_days = []

        # Paramètres dynamiques
        self.warning_level = WARNING_LEVEL_DEFAULT
        self.hi_threshold = HI_THRESHOLD_DEFAULT

        # ROS2 Subscriptions
        self.sub_predicted = self.create_subscription(Float64, 'hi_predit_topic', self.callback_predicted, 10)
        self.sub_rul_pred = self.create_subscription(Float64, 'rul_predicted_topic', self.callback_rul_predicted, 10)
        self.sub_rul_est = self.create_subscription(Float64, 'rul_estimate_topic', self.callback_rul_estimated, 10)

        # ROS2 Publisher
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)

        self.get_logger().info('🚀 ROS2 Interactive Dashboard started.')

        # Variables pour refresh auto
        self.last_update_data = None
        self.data_lock = threading.Lock()
        self.ui_update_event = threading.Event()

        # Lancer Gradio dans un thread
        self.setup_gradio_interface()

    # -------- Callbacks ROS --------
    def callback_predicted(self, msg):
        self.hi_predicted = msg.data
        self.process_prediction()
        # Sauvegarder dernier état pour refresh auto
        with self.data_lock:
            self.last_update_data = self.prepare_dashboard_data()
        self.ui_update_event.set()

    def callback_rul_predicted(self, msg):
        self.rul_predicted = msg.data
        self.logs.append(f"📩 RUL predicted: {self.rul_predicted:.1f} days")
        with self.data_lock:
            self.last_update_data = self.prepare_dashboard_data()
        self.ui_update_event.set()

    def callback_rul_estimated(self, msg):
        self.rul_estimate = msg.data
        self.logs.append(f"📩 RUL estimated: {self.rul_estimate:.1f} days")
        with self.data_lock:
            self.last_update_data = self.prepare_dashboard_data()
        self.ui_update_event.set()

    # -------- Traitement --------
    def process_prediction(self):
        if self.hi_predicted is None:
            return

        self.timestamps.append(self.time)
        current_day = self.time * self.time_per_window
        self.times_days.append(current_day)
        self.time += 1
        self.pred_hi.append(self.hi_predicted)

        # Lissage
        if len(self.pred_hi) > 3:
            self.pred_hi = list(gaussian_filter1d(self.pred_hi, sigma=2))

        last_pred = self.pred_hi[-1]

        if last_pred <= self.warning_level:
            self.logs.append(f"⚠️ Warning level ({self.warning_level}) reached at day {current_day:.1f}")
        if last_pred <= self.hi_threshold:
            self.logs.append(f"🛑 Critical threshold ({self.hi_threshold}) reached at day {current_day:.1f}")

        # Publication ROS2
        alert = Bool()
        self.alert_status = (last_pred <= self.warning_level)
        self.immediate_alert = (last_pred <= self.hi_threshold)
        alert.data = bool(self.alert_status or self.immediate_alert)
        self.publisher_alert.publish(alert)

    # -------- Génération graphique --------
    def get_plotly_figure(self):
        fig = go.Figure()

        if self.pred_hi:
            fig.add_trace(go.Scatter(
                x=self.times_days,
                y=self.pred_hi,
                mode='lines+markers',
                name='Predicted HI',
                line=dict(color='green', width=2)
            ))

        fig.add_hline(y=self.hi_threshold, line=dict(color="red", dash="dash"), annotation_text=f"Threshold {self.hi_threshold}")
        fig.add_hline(y=self.warning_level, line=dict(color="orange", dash="dot"), annotation_text=f"Warning {self.warning_level}")

        fig.update_layout(
            title="📊 Health Index Analysis (Interactive)",
            xaxis_title="Time [Days]",
            yaxis_title="HI",
            yaxis=dict(range=[-0.1, 1.1]),
            xaxis=dict(range=[0, self.total_days]),  # Fixer l'axe X à 30 jours
            template="plotly_white"
        )
        return fig

    # -------- Statut et reco --------
    def get_status(self):
        if not self.pred_hi:
            return "Waiting for data...", "N/A", "N/A", "No alert"

        last_pred = self.pred_hi[-1]
        status = "✅ Good" if last_pred > 0.7 else "⚠️ Warning" if last_pred > self.hi_threshold else "🛑 Failure imminent"

        alert_text = "No alert"
        if self.immediate_alert:
            alert_text = "🛑 Immediate maintenance required"
        elif self.alert_status:
            alert_text = "⚠️ Maintenance recommended"

        rul_pred_text = f"{self.rul_predicted:.1f}" if self.rul_predicted is not None else "N/A"
        rul_est_text = f"{self.rul_estimate:.1f}" if self.rul_estimate is not None else "N/A"

        return status, rul_pred_text, rul_est_text, alert_text

    def get_recommendations(self):
        if self.rul_estimate is None:
            return "⏳ Waiting for RUL estimation..."
        if self.rul_estimate < 3:
            return f"🔧 RUL very low ({self.rul_estimate:.1f} days). Immediate maintenance required."
        elif self.rul_estimate < 10:
            return f"🔧 RUL moderate ({self.rul_estimate:.1f} days). Plan maintenance soon."
        return f"✅ RUL sufficient ({self.rul_estimate:.1f} days). Normal monitoring."

    # -------- Préparer données UI --------
    def prepare_dashboard_data(self):
        status, rul_pred, rul_est, alert = self.get_status()
        fig = self.get_plotly_figure()
        reco = self.get_recommendations()
        logs_text = "\n".join(self.logs[-8:])
        return status, rul_pred, rul_est, alert, fig, logs_text, reco

    # -------- Interface Gradio --------
    def setup_gradio_interface(self):
        with gr.Blocks(title="ROS2 Interactive Health Dashboard") as demo:
            gr.Markdown("# 🏥 ROS2 Interactive HI Dashboard\n*Real-time monitoring & user control*")

            with gr.Row():
                with gr.Column():
                    status_box = gr.Textbox(label="Health Status")
                    rul_pred_box = gr.Textbox(label="Predicted RUL [days]")
                    rul_est_box = gr.Textbox(label="Estimated RUL [days]")
                    alert_box = gr.Textbox(label="Current Alerts")
                with gr.Column():
                    plot = gr.Plot(label="Health Index Plot")

            with gr.Row():
                threshold_slider = gr.Slider(0.05, 0.5, value=HI_THRESHOLD_DEFAULT, step=0.01, label="Critical Threshold")
                warning_slider = gr.Slider(0.1, 0.9, value=WARNING_LEVEL_DEFAULT, step=0.05, label="Warning Level")

            logs_box = gr.Textbox(label="Event Logs", lines=8)
            reco_box = gr.Textbox(label="Recommendations", lines=3)

            # Bouton refresh manuel
            refresh_btn = gr.Button("🔄 Manual Refresh")

            def update_dashboard(threshold, warning):
                self.hi_threshold = threshold
                self.warning_level = warning
                return self.prepare_dashboard_data()

            refresh_btn.click(
                fn=update_dashboard,
                inputs=[threshold_slider, warning_slider],
                outputs=[status_box, rul_pred_box, rul_est_box, alert_box, plot, logs_box, reco_box]
            )

            # Fonction pour la mise à jour automatique
            def auto_update():
                with self.data_lock:
                    if self.last_update_data:
                        data = self.last_update_data
                        self.last_update_data = None
                        return data
                return self.prepare_dashboard_data()

            # Configuration des mises à jour automatiques
            demo.load(
                fn=lambda: self.prepare_dashboard_data(),
                outputs=[status_box, rul_pred_box, rul_est_box, alert_box, plot, logs_box, reco_box]
            )
            
            # Thread pour les mises à jour périodiques
            def periodic_update():
                while True:
                    time.sleep(1.0)  # Mise à jour toutes les secondes
                    try:
                        # Vérifier s'il y a de nouvelles données
                        with self.data_lock:
                            if self.last_update_data:
                                # Juste consommer les données, l'interface se met à jour via demo.load
                                self.last_update_data = None
                    except Exception as e:
                        self.get_logger().error(f"Error in periodic update: {e}")

            # Démarrer le thread de mise à jour périodique
            update_thread = threading.Thread(target=periodic_update, daemon=True)
            update_thread.start()

        # Lancer l'interface dans un thread séparé
        gradio_thread = threading.Thread(
            target=lambda: demo.launch(server_name='0.0.0.0', server_port=7860, share=False),
            daemon=True
        )
        gradio_thread.start()
        self.get_logger().info("Gradio interface running at http://localhost:7860")


def main(args=None):
    rclpy.init(args=args)
    node = ROS2InteractiveDashboard()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
