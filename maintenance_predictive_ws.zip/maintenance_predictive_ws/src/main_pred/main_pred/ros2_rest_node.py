#!/usr/bin/env python3
# ros2_rest_hi_node.py
"""
ros2_rest_hi_node.py
Node ROS2 + REST dashboard en temps réel.
Dépendances: rclpy, fastapi, uvicorn, numpy, scipy
Installation (ex): pip install fastapi uvicorn numpy scipy
"""

import threading
import asyncio
import json
import time
from typing import List, Optional

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool

import numpy as np
from scipy.ndimage import gaussian_filter1d

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# ====== Config / constantes ======
HI_THRESHOLD = 0.05
WARNING_LEVEL = 0.55
WINDOW_FOR_RATE = 5
MAX_DISPLAY_POINTS = 5000
GLOBAL_SMOOTH_INTERVAL = 100
SUPER_SMOOTH_INTERVAL = 1000

# ====== Globals partagés entre uvicorn thread et ROS node ======
# Ces variables seront initialisées par le serveur FastAPI quand il démarre.
OUT_QUEUE: Optional[asyncio.Queue] = None
ASYNC_LOOP: Optional[asyncio.AbstractEventLoop] = None

# ====== Utilitaires ======
def format_days_to_days_hours(days_val: float) -> str:
    days = int(days_val)
    hours = int(round((days_val - days) * 24))
    return f"{days} jours {hours} heures" if hours > 0 else f"{days} jours"

# ====== FastAPI application (dashboard + API + websocket) ======
app = FastAPI(title="HI Analyzer REST Dashboard")

# Autoriser CORS pour développement local
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    """
    Initialise la queue et la boucle asynchrone pour que le node ROS
    puisse poster des messages en faisant run_coroutine_threadsafe(queue.put(...))
    """
    global OUT_QUEUE, ASYNC_LOOP
    ASYNC_LOOP = asyncio.get_event_loop()
    OUT_QUEUE = asyncio.Queue()
    # Lancer la tâche de broadcast
    ASYNC_LOOP.create_task(broadcast_task())

connected_websockets = set()

async def broadcast_task():
    """Consommateur de OUT_QUEUE qui envoie chaque message à tous les websockets connectés."""
    global OUT_QUEUE, connected_websockets
    assert OUT_QUEUE is not None
    while True:
        msg = await OUT_QUEUE.get()
        if msg is None:
            break
        ws_to_remove = []
        data_text = json.dumps(msg)
        for ws in list(connected_websockets):
            try:
                await ws.send_text(data_text)
            except Exception:
                ws_to_remove.append(ws)
        for ws in ws_to_remove:
            connected_websockets.remove(ws)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Point de terminaison websocket pour le dashboard."""
    global connected_websockets
    await websocket.accept()
    connected_websockets.add(websocket)
    try:
        while True:
            # le frontend n'enverra rien par défaut; on attend pour détecter la déconnexion
            await websocket.receive_text()
    except WebSocketDisconnect:
        connected_websockets.discard(websocket)
    except Exception:
        connected_websockets.discard(websocket)

# API REST simples
@app.get("/status")
async def status():
    return {"status": "ok", "node": "hi_analyzer_rest"}

# Stockage léger pour répondre aux endpoints (initialisé par le node)
API_STATE = {
    "last_raw": None,
    "last_smoothed": None,
    "times": [],
    "warning_time": None,
    "threshold_time": None,
    "final_rul": None,
    "warning_crossed": False,
    "threshold_crossed": False
}

@app.get("/metrics")
async def metrics():
    return JSONResponse(API_STATE)

@app.get("/rul")
async def get_rul():
    return {"final_rul": API_STATE["final_rul"]}

# Dashboard HTML (simple) - front minimal avec Chart.js
INDEX_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>HI Analyzer Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 16px; background:#fafafa }
    .header { display:flex; justify-content:space-between; align-items:center }
    canvas { max-width: 100%; height: 400px; background: white; border-radius:8px; box-shadow: 0 2px 6px rgba(0,0,0,0.06); }
    .info { margin-left: 16px; }
  </style>
</head>
<body>
  <div class="header">
    <h2>HI Analyzer Dashboard (en temps réel)</h2>
    <div class="info">
      <div>Warning: <span id="warning_time">—</span></div>
      <div>Threshold: <span id="threshold_time">—</span></div>
      <div>RUL est.: <span id="rul">—</span></div>
    </div>
  </div>
  <canvas id="chart"></canvas>

  <script>
    const ctx = document.getElementById('chart').getContext('2d');
    const rawData = {labels: [], datasets: [{ label: 'Raw HI', data: [], borderColor:'gray', backgroundColor:'rgba(0,0,0,0.02)', pointRadius:1, tension:0.2 }]};
    const smoothData = { label: 'Smoothed HI', data: [], borderColor:'green', borderWidth:2.5, pointRadius:0, tension:0.25 };
    const chart = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: [ rawData.datasets[0], smoothData ] },
      options: {
        animation: false,
        scales: {
          x: { type: 'linear', title: { display:true, text:'time [days]' } },
          y: { min:-0.1, max:1.1, title: { display:true, text:'HI' } }
        },
        plugins: {
          legend: { display:true }
        }
      }
    });

    const ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen = () => console.log('ws open');
    ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      // msg expected shape: { time, raw, smooth, warning_time, threshold_time, rul, warning_crossed, threshold_crossed }
      chart.data.labels.push(msg.time);
      chart.data.datasets[0].data.push({x: msg.time, y: msg.raw});
      chart.data.datasets[1].data.push({x: msg.time, y: msg.smooth});
      // keep last 5000 points (browser side)
      if (chart.data.labels.length > 5000) {
        chart.data.labels.shift();
        chart.data.datasets.forEach(d => d.data.shift());
      }
      document.getElementById('warning_time').innerText = msg.warning_time !== null ? msg.warning_time : '—';
      document.getElementById('threshold_time').innerText = msg.threshold_time !== null ? msg.threshold_time : '—';
      document.getElementById('rul').innerText = msg.rul !== null ? msg.rul : '—';
      chart.update('none');
    };
    ws.onclose = () => console.log('ws closed');
  </script>
</body>
</html>
"""

@app.get("/")
async def index():
    return HTMLResponse(INDEX_HTML)

# ====== Serveur UVicorn dans un thread ======
class UvicornServerThread(threading.Thread):
    def __init__(self, host="0.0.0.0", port=8000):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.started = threading.Event()

    def run(self):
        # demarrer uvicorn server (bloquant) mais dans ce thread
        config = uvicorn.Config(app, host=self.host, port=self.port, log_level="info")
        server = uvicorn.Server(config=config)
        # signale que l'on va démarrer (utile si on veut attendre)
        self.started.set()
        server.run()

# ====== HIAnalyzer ROS2 Node (intègre posting vers ASYNC queue) ======
class HIAnalyzerRESTNode(Node):
    def __init__(self):
        super().__init__('hi_analyzer_rest_node')

        # variables internes
        self.hi_predicted = None
        self.pred_hi: List[float] = []
        self.smooth_local: List[float] = []
        self.smooth_global: List[float] = []
        self.smooth_super: List[float] = []
        self.smooth_hi: List[float] = []
        self.times: List[float] = []
        self.window_count = 0
        self.time_per_window = (30 * 60) / (24 * 3600)  # 30min -> jours

        self.warning_crossed = False
        self.threshold_crossed = False
        self.warning_time = None
        self.threshold_time = None
        self.final_rul = None

        # ROS subscriptions / publishers
        self.sub_predicted = self.create_subscription(Float64, 'hi_predit_topic', self.callback_predicted, 10)
        self.publisher_rul = self.create_publisher(Float64, 'rul_estimate_topic', 10)
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)

        self.get_logger().info("HIAnalyzerRESTNode started")

    # smoothing function (reuse)
    def smooth_signal(self, values):
        arr = np.array(values, dtype=float)
        arr_local = gaussian_filter1d(arr, sigma=2)
        self.smooth_local = arr_local.tolist()
        if len(arr_local) >= GLOBAL_SMOOTH_INTERVAL:
            arr_global = gaussian_filter1d(arr_local, sigma=10)
            self.smooth_global = arr_global.tolist()
        else:
            self.smooth_global = self.smooth_local
        if len(arr_local) >= SUPER_SMOOTH_INTERVAL:
            arr_super = gaussian_filter1d(arr_local, sigma=20)
            self.smooth_super = arr_super.tolist()
        else:
            self.smooth_super = []
        if len(self.smooth_super) > 0:
            return self.smooth_super
        elif len(self.smooth_global) > 0:
            return self.smooth_global
        else:
            return self.smooth_local

    def try_compare(self):
        if self.hi_predicted is None:
            return

        # add new sample
        self.times.append(self.window_count * self.time_per_window)
        self.window_count += 1
        self.pred_hi.append(self.hi_predicted)

        # apply smoothing
        self.smooth_hi = self.smooth_signal(self.pred_hi)

        # helper
        def first_cross_index(arr, threshold):
            idxs = np.where(np.array(arr) <= threshold)[0]
            return int(idxs[0]) if idxs.size > 0 else None

        # detection warning
        if not self.warning_crossed:
            warn_idx = first_cross_index(self.smooth_hi, WARNING_LEVEL)
            if warn_idx is not None:
                self.warning_time = max(self.times[warn_idx], 0.0)
                self.warning_crossed = True
                self.get_logger().info(f'⚠️ Warning detected at {format_days_to_days_hours(self.warning_time)}')

        # detection threshold
        if not self.threshold_crossed:
            thr_idx = first_cross_index(self.smooth_hi, HI_THRESHOLD)
            if thr_idx is not None:
                self.threshold_time = max(self.times[thr_idx], 0.0)
                self.threshold_crossed = True
                self.get_logger().info(f'🛑 Threshold detected at {format_days_to_days_hours(self.threshold_time)}')

        # RUL
        if self.warning_time is not None and self.threshold_time is not None:
            RUL_estimate = self.threshold_time - self.warning_time
            self.publisher_rul.publish(Float64(data=RUL_estimate))
            self.final_rul = RUL_estimate
            self.get_logger().info(f'⏳ Estimated RUL: {format_days_to_days_hours(RUL_estimate)}')

        # update API_STATE (rest endpoint)
        API_STATE["last_raw"] = self.pred_hi[-1]
        # pick last smoothed value available
        last_smoothed = None
        if len(self.smooth_super) > 0:
            last_smoothed = self.smooth_super[-1]
        elif len(self.smooth_global) > 0:
            last_smoothed = self.smooth_global[-1]
        else:
            last_smoothed = self.smooth_local[-1] if len(self.smooth_local)>0 else None

        API_STATE["last_smoothed"] = last_smoothed
        API_STATE["times"] = self.times[-1000:]
        API_STATE["warning_time"] = self.warning_time
        API_STATE["threshold_time"] = self.threshold_time
        API_STATE["final_rul"] = self.final_rul
        API_STATE["warning_crossed"] = self.warning_crossed
        API_STATE["threshold_crossed"] = self.threshold_crossed

        # Publish alert if threshold crossed
        if self.threshold_crossed:
            self.publisher_alert.publish(Bool(data=True))

        # push to websocket queue if available
        global OUT_QUEUE, ASYNC_LOOP
        if OUT_QUEUE is not None and ASYNC_LOOP is not None:
            payload = {
                "time": self.times[-1],
                "raw": float(self.pred_hi[-1]),
                "smooth": float(last_smoothed) if last_smoothed is not None else None,
                "warning_time": self.warning_time,
                "threshold_time": self.threshold_time,
                "rul": self.final_rul,
                "warning_crossed": self.warning_crossed,
                "threshold_crossed": self.threshold_crossed
            }
            # put into the asyncio queue from this thread
            try:
                asyncio.run_coroutine_threadsafe(OUT_QUEUE.put(payload), ASYNC_LOOP)
            except Exception as e:
                self.get_logger().warn(f"Could not post to OUT_QUEUE: {e}")

    def callback_predicted(self, msg: Float64):
        self.hi_predicted = msg.data
        self.try_compare()

# ====== MAIN orchestration ======
def main():
    # 1) start FastAPI server in background thread
    server_thread = UvicornServerThread(host="0.0.0.0", port=8000)
    server_thread.start()
    # wait a little for server thread to initialize (it sets ASYNC_LOOP & OUT_QUEUE in startup event)
    time.sleep(0.5)

    # 2) start ROS2 node in this main thread
    rclpy.init()
    node = HIAnalyzerRESTNode()

    try:
        # spin with small timeout so node remains responsive
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            # light sleep to let other threads run
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        # send sentinel to stop broadcast task gracefully
        global OUT_QUEUE, ASYNC_LOOP
        if OUT_QUEUE is not None and ASYNC_LOOP is not None:
            try:
                asyncio.run_coroutine_threadsafe(OUT_QUEUE.put(None), ASYNC_LOOP)
            except Exception:
                pass

        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()

