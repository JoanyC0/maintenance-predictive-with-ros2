import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import pandas as pd
from datetime import datetime
import os

class HIActualNode(Node):
    def __init__(self):
        super().__init__('hi_actual_node')

        dataset_path = '/home/jacquescormery/maintenance_predictive_ws/dataset/finaldataset_sorted.csv'
        if not os.path.exists(dataset_path):
            self.get_logger().error(f'❌ Fichier introuvable : {dataset_path}')
            raise FileNotFoundError(f"Fichier manquant : {dataset_path}")

        # Chargement du dataset avec noms de colonnes
        col_names = [f'feat_{i}' for i in range(17)] + ['etat', 'etat_text']
        self.df = pd.read_csv(dataset_path, header=None, names=col_names)

        # Supprimer ou remplacer les NaN dans 'etat'
        self.df['etat'] = self.df['etat'].fillna(2)  # valeur 2 = panne

        # Index utilisé pour suivre la fenêtre
        self.index = 0
        self.window_size = 20  # cohérent avec le modèle LSTM

        # HI moyen par cluster
        self.cluster_hi_map = {
            0: 1.0,  # sain
            1: 0.5,  # dégradé
            2: 0.0   # panne
        }

        # Abonnement au signal de fin de prédiction
        self.done_subscription = self.create_subscription(
            Bool,
            'model_done',
            self.done_callback,
            10
        )

        # Publisher HI réel
        self.publisher = self.create_publisher(Float64, 'hi_actual_topic', 10)

        self.get_logger().info('📡 Node HI réel simulé lancé (bruité selon cluster).')

    def done_callback(self, msg: Bool):
        if msg.data:
            # Index du point réel correspondant à la fin de la fenêtre actuelle
            hi_index = self.index + self.window_size - 1

            if hi_index >= len(self.df):
                self.get_logger().warn('⛔ Fin du dataset atteinte, arrêt publication HI réel.')
                return

            row = self.df.iloc[hi_index]
            # Gestion NaN déjà faite à l'initialisation
            cluster = int(row['etat'])
            base_hi = self.cluster_hi_map.get(cluster, 0.0)

            now = datetime.now().strftime('%H:%M:%S.%f')[:-3]
            etat_text = row['etat_text']
            self.get_logger().info(
                f'✅ HI réel à l’index {hi_index} : {base_hi:.3f} '
                f'(Cluster : {cluster} - État : {etat_text}) à {now}'
            )

            msg_pub = Float64()
            msg_pub.data = base_hi
            self.publisher.publish(msg_pub)

            self.get_logger().info(f'📤 HI réel publié à {now}')

            # Avancer la fenêtre d'un pas
            self.index += 1

def main(args=None):
    rclpy.init(args=args)
    node = HIActualNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('🛑 Interruption clavier reçue, arrêt du noeud.')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

