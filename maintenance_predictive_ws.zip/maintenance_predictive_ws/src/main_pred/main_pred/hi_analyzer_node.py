import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from scipy.ndimage import gaussian_filter1d

# ====== Constantes ======
HI_THRESHOLD = 0.05          # Seuil critique HI
WARNING_LEVEL = 0.55         # Seuil de warning
WINDOW_FOR_RATE = 5          # Nb dernières fenêtres pour calcul de dégradation
MAX_DISPLAY_POINTS = 5000    # Nombre max de points affichés
GLOBAL_SMOOTH_INTERVAL = 100  # Appliquer le lissage global tous les N points
SUPER_SMOOTH_INTERVAL = 1000  # Appliquer un lissage très fort tous les 500 points

def format_days_to_days_hours(days_val: float) -> str:
    """Convertit un temps en jours décimaux vers 'X jours Y heures'."""
    days = int(days_val)
    hours = int(round((days_val - days) * 24))
    return f"{days} jours {hours} heures" if hours > 0 else f"{days} jours"

class HIAnalyzerNode(Node):
    def __init__(self):
        super().__init__('hi_analyzer_node')

        # ====== Variables internes ======
        self.hi_predicted = None
        self.pred_hi = []           # valeurs brutes HI prédites
        self.smooth_local = []      # lissage local
        self.smooth_global = []     # lissage global
        self.smooth_super = []      # lissage très fort (super global)
        self.smooth_hi = []         # signal utilisé pour analyse
        self.times = []             # échelle de temps (jours)
        self.window_count = 0
        hours = 1  
        self.time_per_window = hours / 24 



        # Flags état
        self.warning_crossed = False
        self.threshold_crossed = False
        self.warning_time = None
        self.threshold_time = None

        # RUL réel
        self.final_rul = 0.0

        # ====== ROS2 abonnements/publications ======
        self.sub_predicted = self.create_subscription(
            Float64, 'hi_predit_topic', self.callback_predicted, 10
        )
        self.publisher_rul = self.create_publisher(Float64, 'rul_estimate_topic', 10)
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)

        self.get_logger().info('🔍 HI analysis .')

        # ====== Graphiques ======
        self.warning_line = None
        self.threshold_line = None
        self.setup_plot()

    # ====== Callback ROS ======
    def callback_predicted(self, msg):
        self.hi_predicted = msg.data
        self.try_compare()

    # ====== Triple lissage gaussien ======
    def smooth_signal(self, values):
        arr = np.array(values, dtype=float)

        # 1) Lissage local
        arr_local = gaussian_filter1d(arr, sigma=2)
        self.smooth_local = arr_local.tolist()

        # 2) Lissage global
        if len(arr_local) >= GLOBAL_SMOOTH_INTERVAL:
            arr_global = gaussian_filter1d(arr_local, sigma=10)
            self.smooth_global = arr_global.tolist()
        else:
            self.smooth_global = self.smooth_local

        # 3) Lissage super fort
        if len(arr_local) >= SUPER_SMOOTH_INTERVAL:
            arr_super = gaussian_filter1d(arr_local, sigma=20)
            self.smooth_super = arr_super.tolist()
        else:
            self.smooth_super = []

        # Signal utilisé pour détection
        if len(self.smooth_super) > 0:
            return self.smooth_super
        elif len(self.smooth_global) > 0:
            return self.smooth_global
        else:
            return self.smooth_local

    # ====== Analyse des seuils et RUL ======
    def try_compare(self):
        if self.hi_predicted is None:
            return

        # Ajout nouvelle donnée
        self.times.append(self.window_count * self.time_per_window)
        self.window_count += 1
        self.pred_hi.append(self.hi_predicted)

        # Application du lissage
        self.smooth_hi = self.smooth_signal(self.pred_hi)

        # Fonction utilitaire
        def first_cross_index(arr, threshold):
            idxs = np.where(np.array(arr) <= threshold)[0]
            return int(idxs[0]) if idxs.size > 0 else None

        # ====== Détection warning ======
        if not self.warning_crossed:
            warn_idx = first_cross_index(self.smooth_hi, WARNING_LEVEL)
            if warn_idx is not None:
                self.warning_time = max(self.times[warn_idx], 0.0)
                self.warning_crossed = True
                formatted_time = format_days_to_days_hours(self.warning_time)
                self.get_logger().info(f'⚠️ Warning detected at {formatted_time}.')
                self.warning_line = self.ax.axvline(
                    self.warning_time, color='black', linestyle='--', linewidth=2, label='Warning'
                )

        # ====== Détection seuil critique ======
        if not self.threshold_crossed:
            thr_idx = first_cross_index(self.smooth_hi, HI_THRESHOLD)
            if thr_idx is not None:
                self.threshold_time = max(self.times[thr_idx], 0.0)
                self.threshold_crossed = True
                formatted_time = format_days_to_days_hours(self.threshold_time)
                self.get_logger().info(f'🛑 Threshold detected at {formatted_time}.')
                self.threshold_line = self.ax.axvline(
                    self.threshold_time, color='black', linestyle='--', linewidth=2, label='Threshold'
                )

        # ====== RUL réel ======
        if self.warning_time is not None and self.threshold_time is not None:
            RUL_estimate = self.threshold_time - self.warning_time
            self.publisher_rul.publish(Float64(data=RUL_estimate))
            formatted_rul = format_days_to_days_hours(RUL_estimate)
            self.get_logger().info(f'⏳ Estimated RUL: {formatted_rul}')
            self.final_rul = RUL_estimate

    # ====== Graphiques ======
    def setup_plot(self):
        self.fig, self.ax = plt.subplots()
        self.ax.set_title("📈 Health Index Analysis")
        self.ax.set_xlabel("Time [days]")
        self.ax.set_ylabel("HI")
        self.ax.set_ylim(-0.1, 1.1)
        self.line_pred, = self.ax.plot([], [], label='Smoothed HI', color='green', linewidth=2.5)
        self.line_raw, = self.ax.plot([], [], label='Raw HI', color='gray', alpha=0.4, linewidth=1)

        # Zones colorées
        self.ax.axhspan(0.7, 1.1, facecolor='white', alpha=0.1)
        self.ax.axhspan(0.3, 0.7, facecolor='white', alpha=0.1)
        self.ax.axhspan(-0.1, 0.3, facecolor='white', alpha=0.1)

        # Étiquettes
        self.ax.text(0.99, 0.85, " Good condition", ha='right', va='center',
                     fontsize=12, color='green', alpha=0.9,
                     transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.5, " Warning", ha='right', va='center',
                     fontsize=12, color='orange', alpha=0.9,
                     transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.15, " Imminent failure", ha='right', va='center',
                     fontsize=12, color='red', alpha=0.9,
                     transform=self.ax.get_yaxis_transform())

        # Ligne de seuil
        self.ax.axhline(HI_THRESHOLD, color='red', linestyle='--', linewidth=2, label='HI Threshold')
        self.ax.legend(loc='upper left', framealpha=0.5)

        # Animation dynamique
        self.ani = animation.FuncAnimation(self.fig, self.update_plot, interval=500)
        plt.tight_layout()
        plt.show(block=False)

    def update_plot(self, frame):
        if len(self.times) > 0:
            # Choisir le signal le plus fort disponible
            if len(self.smooth_super) > 0:
                display_hi = self.smooth_super
            elif len(self.smooth_global) > 0:
                display_hi = self.smooth_global
            else:
                display_hi = self.smooth_local

            # Décimation si trop de points
            if len(self.times) > MAX_DISPLAY_POINTS:
                step = len(self.times) // MAX_DISPLAY_POINTS
                times_disp = self.times[::step]
                raw_disp = self.pred_hi[::step]
                smooth_disp = display_hi[::step]
            else:
                times_disp = self.times
                raw_disp = self.pred_hi
                smooth_disp = display_hi

            # Mise à jour des courbes
            self.line_pred.set_data(times_disp, smooth_disp)
            self.line_raw.set_data(times_disp, raw_disp)

            # Ajustement automatique des limites X
            self.ax.set_xlim(0, self.times[-1] + self.time_per_window)

            # Mise à jour des lignes de warning / threshold
            if self.warning_line is not None:
                self.warning_line.set_xdata(self.warning_time)
            if self.threshold_line is not None:
                self.threshold_line.set_xdata(self.threshold_time)

        return self.line_pred, self.line_raw

# ====== MAIN ======
def main(args=None):
    rclpy.init(args=args)
    node = HIAnalyzerNode()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            plt.pause(0.01)
    except KeyboardInterrupt:
        pass

    if node.warning_crossed and node.threshold_crossed:
        node.publisher_rul.publish(Float64(data=node.final_rul))
        formatted_final = format_days_to_days_hours(node.final_rul)
        node.get_logger().info(f"📤 Final RUL published: {formatted_final}")

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

