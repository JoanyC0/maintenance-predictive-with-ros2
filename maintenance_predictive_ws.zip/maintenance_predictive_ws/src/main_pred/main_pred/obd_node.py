import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, Bool
import pandas as pd
import joblib
import signal
import sys
import os
import obd   # librairie python-OBD


class PreprocessingNode(Node):
    def __init__(self):
        super().__init__('obd_node')

        # Colonnes utilisées pour le scaler pré-entraîné
        self.colonnes_utiles = [
            'ENGINE_RUN_TINE',
            'ENGINE_RPM',
            'VEHICLE_SPEED',
            'THROTTLE',
            'ENGINE_LOAD',
            'COOLANT_TEMPERATURE',
            'LONG_TERM_FUEL_TRIM_BANK_1',
            'SHORT_TERM_FUEL_TRIM_BANK_1',
            'INTAKE_MANIFOLD_PRESSURE',
            'FUEL_TANK',
            'FUEL_AIR_COMMANDED_EQUIV_RATIO',
            'ABSOLUTE_BAROMETRIC_PRESSURE',
            'INTAKE_AIR_TEMP',
            'TIMING_ADVANCE',
            'CATALYST_TEMPERATURE_BANK1_SENSOR1',
            'CATALYST_TEMPERATURE_BANK1_SENSOR2',
            'CONTROL_MODULE_VOLTAGE',
        ]

        # Mapping PID ↔ colonne (selon python-OBD)
        self.obd_commands = {
            'ENGINE_RUN_TINE': obd.commands.RUN_TIME,              # Engine run time
            'ENGINE_RPM': obd.commands.RPM,                        # RPM
            'VEHICLE_SPEED': obd.commands.SPEED,                   # Vehicle speed
            'THROTTLE': obd.commands.THROTTLE_POS,                 # Throttle position
            'ENGINE_LOAD': obd.commands.ENGINE_LOAD,               # Engine load
            'COOLANT_TEMPERATURE': obd.commands.COOLANT_TEMP,      # Coolant temp
            'LONG_TERM_FUEL_TRIM_BANK_1': obd.commands.LONG_FUEL_TRIM_1,  # LTFT B1
            'SHORT_TERM_FUEL_TRIM_BANK_1': obd.commands.SHORT_FUEL_TRIM_1, # STFT B1
            'INTAKE_MANIFOLD_PRESSURE': obd.commands.INTAKE_PRESSURE,      # Intake manifold pressure
            'FUEL_TANK': obd.commands.FUEL_LEVEL,                  # Fuel level (%)
            'FUEL_AIR_COMMANDED_EQUIV_RATIO': obd.commands.COMMANDED_EQUIV_RATIO,  # Equivalence ratio
            'ABSOLUTE_BAROMETRIC_PRESSURE': obd.commands.BAROMETRIC_PRESSURE, # Barometric pressure
            'INTAKE_AIR_TEMP': obd.commands.INTAKE_TEMP,           # Intake air temp
            'TIMING_ADVANCE': obd.commands.TIMING_ADVANCE,         # Timing advance
            'CATALYST_TEMPERATURE_BANK1_SENSOR1': obd.commands.CATALYST_TEMP_B1S1, # Catalyst Temp
            'CATALYST_TEMPERATURE_BANK1_SENSOR2': obd.commands.CATALYST_TEMP_B1S2, # Catalyst Temp
            'CONTROL_MODULE_VOLTAGE': obd.commands.CONTROL_MODULE_VOLTAGE, # Control module voltage
        }

        self.data = []

        # Fichier CSV
        self.csv_file = "dataset_normalized.csv"
        if not os.path.exists(self.csv_file):
            pd.DataFrame(columns=self.colonnes_utiles).to_csv(self.csv_file, index=False, header=False)

        # Publishers ROS 2
        self.model_publisher = self.create_publisher(Float64MultiArray, 'obd_data', 10)
        self.publisher_done = self.create_publisher(Bool, 'publisher_done', 10)

        # Charger le scaler pré-entraîné
        scaler_path = "/home/jacquescormery/maintenance_predictive_ws/models/fichier_de_normalisation.pkl"
        if os.path.exists(scaler_path):
            self.scaler = joblib.load(scaler_path)
            self.get_logger().info("✅ Scaler pré-entraîné chargé pour normalisation temps réel.")
        else:
            self.get_logger().error(f"❌ Fichier {scaler_path} introuvable ! Normalisation temps réel impossible.")
            sys.exit(1)

        # Connexion OBD-II
        self.connection = obd.OBD()  # auto-détection port série
        if self.connection.is_connected():
            self.get_logger().info("✅ Connecté à l’OBD-II.")
        else:
            self.get_logger().error("❌ Impossible de se connecter à l’OBD-II.")
            sys.exit(1)

        signal.signal(signal.SIGINT, self.cleanup_and_exit)
        self.get_logger().info("✅ preprocessing_node_obd lancé : acquisition données réelles...")

        # Collecte en continu toutes les 0.5 s
        self.create_timer(0.5, self.collect_obd_data)

        # Intervalle de publication configurable en heures
        self.publish_interval_hours = 1.0  # toutes les heures
        self.create_timer(self.publish_interval_hours * 3600.0, self.publish_data)

        # Paramètres de fenêtre
        self.window_size = 20
        self.last_published_index = 0

    def collect_obd_data(self):
        ligne = {}
        for col, cmd in self.obd_commands.items():
            response = self.connection.query(cmd)
            if not response.is_null():
                ligne[col] = response.value.magnitude  # valeur brute
            else:
                ligne[col] = 0.0  # valeur manquante par défaut

        self.data.append(ligne)

        # Sauvegarde brute / 255 pour suivi
        df_temp = pd.DataFrame([ligne])
        df_norm = df_temp / 255.0
        df_norm.to_csv(self.csv_file, mode='a', header=False, index=False)

        self.get_logger().info(f"Ligne OBD ajoutée : {ligne}")

    def publish_data(self):
        # Attendre au moins 20 lignes avant de publier
        if len(self.data) < self.window_size:
            self.get_logger().warning("⏳ En attente d'au moins 20 lignes pour commencer la publication...")
            return

        # Vérifier si une nouvelle fenêtre glissante est disponible
        if self.last_published_index + self.window_size <= len(self.data):
            current_window = self.data[self.last_published_index:self.last_published_index + self.window_size]
            df_window = pd.DataFrame(current_window)

            # Normalisation temps réel
            df_window_norm = pd.DataFrame(self.scaler.transform(df_window), columns=self.colonnes_utiles)

            msg = Float64MultiArray()
            msg.data = df_window_norm.values.flatten().tolist()
            self.model_publisher.publish(msg)

            self.get_logger().info(
                f"📤 Fenêtre publiée : lignes {self.last_published_index} → {self.last_published_index + self.window_size}"
            )

            # Décalage d'une ligne
            self.last_published_index += 1
        else:
            self.get_logger().info("✅ Pas encore assez de nouvelles données pour la prochaine fenêtre.")

    def cleanup_and_exit(self, signum=None, frame=None):
        self.get_logger().info("Arrêt demandé → preprocessing_obd terminé")
        if len(self.data) == 0:
            self.get_logger().warning("Aucune donnée collectée")
            sys.exit(0)

        df_full = pd.DataFrame(self.data)
        df_norm_full = pd.DataFrame(self.scaler.transform(df_full), columns=self.colonnes_utiles)
        df_norm_full.to_csv("dataset_normalized_global.csv", index=False, header=False)

        self.get_logger().info(f"✅ dataset_normalized_global.csv généré avec {len(self.data)} lignes")
        sys.exit(0)


def main(args=None):
    rclpy.init(args=args)
    node = PreprocessingNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.cleanup_and_exit()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

