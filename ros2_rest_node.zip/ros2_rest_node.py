#!/usr/bin/env python3
# ros2_rest_hi_node.py
"""
ros2_rest_hi_node.py
Node ROS2 + REST dashboard en temps réel avec persistance de l'historique.
"""

import threading
import asyncio
import json
import time
from typing import List, Optional

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool

import numpy as np
from scipy.ndimage import gaussian_filter1d

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# ====== Config ======
HI_THRESHOLD = 0.05
WARNING_LEVEL = 0.55
GLOBAL_SMOOTH_INTERVAL = 100
SUPER_SMOOTH_INTERVAL = 1000

# ====== Globals ======
OUT_QUEUE: Optional[asyncio.Queue] = None
ASYNC_LOOP: Optional[asyncio.AbstractEventLoop] = None

# ====== Utils ======
def format_days_to_days_hours(days_val: float) -> str:
    days = int(days_val)
    hours = int(round((days_val - days) * 24))
    return f"{days} jours {hours} heures" if hours > 0 else f"{days} jours"

# ====== FastAPI ======
app = FastAPI(title="HI Analyzer REST Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    global OUT_QUEUE, ASYNC_LOOP
    ASYNC_LOOP = asyncio.get_event_loop()
    OUT_QUEUE = asyncio.Queue()
    ASYNC_LOOP.create_task(broadcast_task())

connected_websockets = set()

async def broadcast_task():
    global OUT_QUEUE, connected_websockets
    assert OUT_QUEUE is not None
    while True:
        msg = await OUT_QUEUE.get()
        if msg is None:
            break
        ws_to_remove = []
        data_text = json.dumps(msg)
        for ws in list(connected_websockets):
            try:
                await ws.send_text(data_text)
            except Exception:
                ws_to_remove.append(ws)
        for ws in ws_to_remove:
            connected_websockets.remove(ws)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global connected_websockets
    await websocket.accept()
    connected_websockets.add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        connected_websockets.discard(websocket)
    except Exception:
        connected_websockets.discard(websocket)

@app.get("/status")
async def status():
    return {"status": "ok", "node": "hi_analyzer_rest"}

# ====== API STATE avec historique ======
API_STATE = {
    "last_raw": None,
    "last_smoothed": None,
    "warning_time": None,
    "threshold_time": None,
    "final_rul": None,
    "warning_crossed": False,
    "threshold_crossed": False,
    "history": []  # ← toute la courbe (liste de dicts)
}

@app.get("/metrics")
async def metrics():
    return JSONResponse(API_STATE)

@app.get("/rul")
async def get_rul():
    return {"final_rul": API_STATE["final_rul"]}

# ====== Dashboard HTML ======
INDEX_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>HI Analyzer Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 16px; background:#f4f6f9; }
    .header { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
    canvas { max-width: 100%; height: 400px; background: white; border-radius:8px; box-shadow: 0 2px 6px rgba(0,0,0,0.06); margin-bottom:20px; }
    .card { background:white; padding:12px 16px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.06); margin:8px; flex:1; }
    .cards { display:flex; flex-wrap:wrap; }
    .metric { font-size:1.2em; font-weight:bold; }
    .ok { color:green; }
    .warn { color:orange; }
    .alert { color:red; }
  </style>
</head>
<body>
  <div class="header">
    <h2>HI Analyzer Dashboard (Temps réel)</h2>
    <div>Status Node: <span id="status" class="ok">Connecté</span></div>
  </div>

  <canvas id="chart"></canvas>

  <div class="cards">
    <div class="card">Raw HI: <span class="metric" id="raw">—</span></div>
    <div class="card">Smoothed HI: <span class="metric" id="smooth">—</span></div>
    <div class="card">Warning Time: <span class="metric warn" id="warning_time">—</span></div>
    <div class="card">Threshold Time: <span class="metric alert" id="threshold_time">—</span></div>
    <div class="card">RUL Est.: <span class="metric" id="rul">—</span></div>
    <div class="card">Warning Crossed: <span id="warning_crossed">—</span></div>
    <div class="card">Threshold Crossed: <span id="threshold_crossed">—</span></div>
  </div>

  <script>
    const ctx = document.getElementById('chart').getContext('2d');
    const chart = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: [
        { label: 'Raw HI', data: [], borderColor:'gray', pointRadius:1, tension:0.2 },
        { label: 'Smoothed HI', data: [], borderColor:'green', borderWidth:2, pointRadius:0, tension:0.25 }
      ]},
      options: {
        animation: false,
        scales: {
          x: { type: 'linear', title: { display:true, text:'Time [days]' } },
          y: { min:-0.1, max:1.1, title: { display:true, text:'HI' } }
        },
        plugins: { legend: { display:true } }
      }
    });

    // Fonction mise à jour des cartes
    function updateCards(msg) {
      document.getElementById('raw').innerText = msg.raw.toFixed(3);
      document.getElementById('smooth').innerText = msg.smooth !== null ? msg.smooth.toFixed(3) : '—';
      document.getElementById('warning_time').innerText = msg.warning_time !== null ? msg.warning_time.toFixed(2) + 'j' : '—';
      document.getElementById('threshold_time').innerText = msg.threshold_time !== null ? msg.threshold_time.toFixed(2) + 'j' : '—';
      document.getElementById('rul').innerText = msg.rul !== null ? msg.rul.toFixed(2) + 'j' : '—';
      document.getElementById('warning_crossed').innerText = msg.warning_crossed ? '✅' : '—';
      document.getElementById('threshold_crossed').innerText = msg.threshold_crossed ? '✅' : '—';
    }

    // Charger l'historique au démarrage
    fetch('/metrics')
      .then(r => r.json())
      .then(data => {
        if (data.history) {
          data.history.forEach(pt => {
            chart.data.labels.push(pt.time);
            chart.data.datasets[0].data.push({x: pt.time, y: pt.raw});
            chart.data.datasets[1].data.push({x: pt.time, y: pt.smooth});
          });
          chart.update();
        }
        updateCards(data);
      });

    // Connexion WebSocket
    const ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen = () => { document.getElementById('status').innerText = 'Connecté'; };
    ws.onclose = () => { document.getElementById('status').innerText = 'Déconnecté'; document.getElementById('status').className = 'alert'; };
    ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      chart.data.labels.push(msg.time);
      chart.data.datasets[0].data.push({x: msg.time, y: msg.raw});
      chart.data.datasets[1].data.push({x: msg.time, y: msg.smooth});
      chart.update('none');
      updateCards(msg);
    };
  </script>
</body>
</html>
"""

@app.get("/")
async def index():
    return HTMLResponse(INDEX_HTML)

# ====== UVicorn thread ======
class UvicornServerThread(threading.Thread):
    def __init__(self, host="0.0.0.0", port=8000):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.started = threading.Event()

    def run(self):
        config = uvicorn.Config(app, host=self.host, port=self.port, log_level="info")
        server = uvicorn.Server(config=config)
        self.started.set()
        server.run()

# ====== HIAnalyzer Node ======
class HIAnalyzerRESTNode(Node):
    def __init__(self):
        super().__init__('hi_analyzer_rest_node')
        self.hi_predicted = None
        self.pred_hi: List[float] = []
        self.smooth_local: List[float] = []
        self.smooth_global: List[float] = []
        self.smooth_super: List[float] = []
        self.smooth_hi: List[float] = []
        self.times: List[float] = []
        self.window_count = 0
        self.time_per_window = (30 * 60) / (24 * 3600)
        self.warning_crossed = False
        self.threshold_crossed = False
        self.warning_time = None
        self.threshold_time = None
        self.final_rul = None
        self.sub_predicted = self.create_subscription(Float64, 'hi_predit_topic', self.callback_predicted, 10)
        self.publisher_rul = self.create_publisher(Float64, 'rul_estimate_topic', 10)
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)
        self.get_logger().info("HIAnalyzerRESTNode started")

    def smooth_signal(self, values):
        arr = np.array(values, dtype=float)
        arr_local = gaussian_filter1d(arr, sigma=2)
        self.smooth_local = arr_local.tolist()
        if len(arr_local) >= GLOBAL_SMOOTH_INTERVAL:
            self.smooth_global = gaussian_filter1d(arr_local, sigma=10).tolist()
        else:
            self.smooth_global = self.smooth_local
        if len(arr_local) >= SUPER_SMOOTH_INTERVAL:
            self.smooth_super = gaussian_filter1d(arr_local, sigma=20).tolist()
        else:
            self.smooth_super = []
        if len(self.smooth_super) > 0:
            return self.smooth_super
        elif len(self.smooth_global) > 0:
            return self.smooth_global
        else:
            return self.smooth_local

    def try_compare(self):
        if self.hi_predicted is None: return
        self.times.append(self.window_count * self.time_per_window)
        self.window_count += 1
        self.pred_hi.append(self.hi_predicted)
        self.smooth_hi = self.smooth_signal(self.pred_hi)

        def first_cross_index(arr, threshold):
            idxs = np.where(np.array(arr) <= threshold)[0]
            return int(idxs[0]) if idxs.size > 0 else None

        if not self.warning_crossed:
            warn_idx = first_cross_index(self.smooth_hi, WARNING_LEVEL)
            if warn_idx is not None:
                self.warning_time = max(self.times[warn_idx], 0.0)
                self.warning_crossed = True
                self.get_logger().info(f'⚠️ Warning detected at {format_days_to_days_hours(self.warning_time)}')

        if not self.threshold_crossed:
            thr_idx = first_cross_index(self.smooth_hi, HI_THRESHOLD)
            if thr_idx is not None:
                self.threshold_time = max(self.times[thr_idx], 0.0)
                self.threshold_crossed = True
                self.get_logger().info(f'🛑 Threshold detected at {format_days_to_days_hours(self.threshold_time)}')

        if self.warning_time is not None and self.threshold_time is not None:
            RUL_estimate = self.threshold_time - self.warning_time
            self.publisher_rul.publish(Float64(data=RUL_estimate))
            self.final_rul = RUL_estimate
            self.get_logger().info(f'⏳ Estimated RUL: {format_days_to_days_hours(RUL_estimate)}')

        last_smoothed = (self.smooth_super[-1] if len(self.smooth_super)>0 else
                         self.smooth_global[-1] if len(self.smooth_global)>0 else
                         self.smooth_local[-1] if len(self.smooth_local)>0 else None)

        API_STATE.update({
            "last_raw": self.pred_hi[-1],
            "last_smoothed": last_smoothed,
            "warning_time": self.warning_time,
            "threshold_time": self.threshold_time,
            "final_rul": self.final_rul,
            "warning_crossed": self.warning_crossed,
            "threshold_crossed": self.threshold_crossed
        })

        # Ajouter le point courant à l'historique
        API_STATE["history"].append({
            "time": self.times[-1],
            "raw": float(self.pred_hi[-1]),
            "smooth": float(last_smoothed) if last_smoothed is not None else None
        })

        if self.threshold_crossed:
            self.publisher_alert.publish(Bool(data=True))

        global OUT_QUEUE, ASYNC_LOOP
        if OUT_QUEUE is not None and ASYNC_LOOP is not None:
            payload = {
                "time": self.times[-1],
                "raw": float(self.pred_hi[-1]),
                "smooth": float(last_smoothed) if last_smoothed is not None else None,
                "warning_time": self.warning_time,
                "threshold_time": self.threshold_time,
                "rul": self.final_rul,
                "warning_crossed": self.warning_crossed,
                "threshold_crossed": self.threshold_crossed
            }
            try:
                asyncio.run_coroutine_threadsafe(OUT_QUEUE.put(payload), ASYNC_LOOP)
            except Exception as e:
                self.get_logger().warn(f"Could not post to OUT_QUEUE: {e}")

    def callback_predicted(self, msg: Float64):
        self.hi_predicted = msg.data
        self.try_compare()

def main():
    server_thread = UvicornServerThread(host="0.0.0.0", port=8000)
    server_thread.start()
    time.sleep(0.5)
    rclpy.init()
    node = HIAnalyzerRESTNode()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        global OUT_QUEUE, ASYNC_LOOP
        if OUT_QUEUE is not None and ASYNC_LOOP is not None:
            try:
                asyncio.run_coroutine_threadsafe(OUT_QUEUE.put(None), ASYNC_LOOP)
            except Exception:
                pass
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()

