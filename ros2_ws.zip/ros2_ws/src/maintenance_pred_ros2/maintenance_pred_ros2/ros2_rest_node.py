import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.animation as animation
from scipy.ndimage import gaussian_filter1d
import gradio as gr
import threading
import numpy as np
import time

HI_THRESHOLD = 0.1  # seuil critique de HI

class ROS2RESTNode(Node):
    def __init__(self):
        super().__init__('ros2_rest_node')
        
        self.hi_predicted = None
        self.rul_estimate = 0.0
        self.alert_status = False
        self.immediate_alert = False

        self.pred_hi = []
        self.timestamps = []
        self.time = 0
        self.last_update = time.time()

        # Subscription uniquement pour HI prédit
        self.sub_predicted = self.create_subscription(
            Float64,
            'hi_predit_topic',
            self.callback_predicted,
            10)

        # Publishers
        self.publisher_rul = self.create_publisher(Float64, 'rul_estimate_topic', 10)
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)

        self.get_logger().info('🔍 ROS2 REST Node with Gradio interface started.')

        # Setup matplotlib plot first
        self.setup_plot()
        
        # Setup Gradio interface
        self.setup_gradio_interface()

    def callback_predicted(self, msg):
        self.hi_predicted = msg.data
        self.try_compare()

    def try_compare(self):
        if self.hi_predicted is None:
            return

        # ---- Calcul RUL ----
        self.rul_estimate = max(0.0, (self.hi_predicted - HI_THRESHOLD) / max(self.hi_predicted, 1e-6))
        msg_rul = Float64()
        msg_rul.data = self.rul_estimate
        self.publisher_rul.publish(msg_rul)

        self.get_logger().info(f'⏳ RUL estimé: {self.rul_estimate:.3f}')

        # ---- Détection alerte ----
        alert = Bool()
        self.alert_status = (self.rul_estimate <= 0.7)
        self.immediate_alert = (self.rul_estimate <= 0.5)
        
        alert.data = self.alert_status or self.immediate_alert
        self.publisher_alert.publish(alert)
        
        if self.immediate_alert:
            self.get_logger().warn("🛑 Maintenance immédiate : RUL ≤ 0.5")
        elif self.alert_status:
            self.get_logger().warn("⚠️ Alerte maintenance : RUL ≤ 0.7")

        # ---- Mise à jour historique ----
        self.timestamps.append(self.time)
        self.time += 1
        self.pred_hi.append(self.hi_predicted)

        # ---- Appliquer un lissage gaussien sur la série pred_hi ----
        if len(self.pred_hi) > 3:  # au moins quelques points
            self.pred_hi = list(gaussian_filter1d(self.pred_hi, sigma=2))

        self.last_update = time.time()

    def setup_plot(self):
        self.fig, self.ax = plt.subplots(figsize=(10, 6))
        self.ax.set_title("Health Index Analysis")
        self.ax.set_xlabel("Window #")
        self.ax.set_ylabel("HI")
        self.ax.set_ylim(-0.1, 1.1)

        self.line_pred, = self.ax.plot([], [], label='Predicted HI', color='green', linewidth=2.5)

        # Zones colorées
        self.ax.axhspan(0.7, 1.1, facecolor='green', alpha=0.1)
        self.ax.axhspan(0.3, 0.7, facecolor='orange', alpha=0.1)
        self.ax.axhspan(-0.1, 0.3, facecolor='red', alpha=0.1)

        # Légendes zones
        self.ax.text(0.99, 0.85, "Good condition", ha='right', va='center', fontsize=12, color='green', alpha=0.9, transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.5, "Warning", ha='right', va='center', fontsize=12, color='orange', alpha=0.9, transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.15, "Imminent failure", ha='right', va='center', fontsize=12, color='red', alpha=0.9, transform=self.ax.get_yaxis_transform())

        # Texte statut HI
        self.status_text = self.ax.text(
            0.01, -0.12, "", transform=self.ax.transAxes,
            ha='left', fontsize=13, fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.9, boxstyle='round,pad=0.3')
        )

        # Texte RUL
        self.rul_text = self.ax.text(
            0.5, -0.12, "", transform=self.ax.transAxes,
            ha='center', fontsize=12, fontweight='bold',
            bbox=dict(facecolor='lightgrey', alpha=0.9, boxstyle='round,pad=0.3')
        )

        self.ax.legend(loc='upper left')

        # Ajustement des marges et cadrage pour tout voir
        self.fig.subplots_adjust(bottom=0.3)
        self.fig.tight_layout(rect=[0, 0, 1, 0.95])

    def update_plot(self):
        if self.timestamps:
            self.line_pred.set_data(self.timestamps, self.pred_hi)
            self.ax.set_xlim(0, max(self.timestamps)+1)

        if self.pred_hi:
            last_pred = self.pred_hi[-1]
            if last_pred > 0.7:
                label = "Good condition"
                color = "green"
            elif last_pred > 0.3:
                label = "Warning"
                color = "orange"
            else:
                label = "Imminent failure"
                color = "red"
            self.status_text.set_text(label)
            self.status_text.set_color(color)

            self.rul_text.set_text(f"RUL estimé: {self.rul_estimate:.2f}")
            self.rul_text.set_color("red" if self.rul_estimate <= 0.5 else "black")

        self.fig.canvas.draw()

    def get_current_status(self):
        if not self.pred_hi:
            return "Waiting for data...", "N/A", "No alert", "No data"
        
        last_pred = self.pred_hi[-1]
        if last_pred > 0.7:
            status = "✅ Good condition"
        elif last_pred > 0.3:
            status = "⚠️ Warning"
        else:
            status = "🛑 Imminent failure"
        
        alert_text = "No alert"
        if self.immediate_alert:
            alert_text = "🛑 IMMEDIATE MAINTENANCE REQUIRED"
        elif self.alert_status:
            alert_text = "⚠️ Maintenance alert"
        
        return status, f"{self.rul_estimate:.3f}", alert_text, f"{len(self.timestamps)} data points"

    def get_plot_figure(self):
        self.update_plot()
        return self.fig

    def get_recommendations(self):
        # Recommandations dynamiques selon le RUL et état
        recs = []
        
        if self.rul_estimate > 0.7:
            recs.append("✅ Système en bon état. Continuer la surveillance régulière.")
            recs.append("Vérifier périodiquement la vitesse et la température du moteur.")
        elif self.rul_estimate > 0.5:
            recs.append("⚠️ Dégradation détectée. Réduire les charges élevées (vitesse/RPM).")
            recs.append("Contrôler la température du liquide de refroidissement et l’air d’admission.")
            recs.append("Prévoir une inspection préventive prochainement.")
        elif self.rul_estimate > 0.3:
            recs.append("⚠️ RUL faible. Limiter l’utilisation du véhicule à des trajets courts.")
            recs.append("Vérifier la pression barométrique et les tensions module de contrôle.")
            recs.append("Planifier une maintenance dans les plus brefs délais.")
        else:
            recs.append("🛑 RUL critique. Maintenance immédiate nécessaire.")
            recs.append("Contrôler en priorité: température catalyseur, tension module, régime moteur.")
            recs.append("Arrêter le véhicule dès que possible pour éviter une panne.")

        return "\n".join(recs)

    def setup_gradio_interface(self):
        with gr.Blocks(title="ROS2 Health Index Monitor", refresh_interval=1) as demo:
            gr.Markdown("# Health Index Monitoring Dashboard")
            gr.Markdown("Real-time monitoring of equipment health index and RUL estimation")
            
            with gr.Row():
                with gr.Column():
                    status_box = gr.Textbox(label="Current Status", interactive=False)
                    rul_box = gr.Textbox(label="RUL Estimate", interactive=False)
                    alert_box = gr.Textbox(label="Alerts", interactive=False)
                    data_count = gr.Textbox(label="Data Points", interactive=False)
                
                with gr.Column():
                    plot = gr.Plot(label="Health Index Analysis")

            gr.Markdown("## Recommendation - Maintenance Suggestions")
            recommendation_box = gr.Textbox(label="Recommendations", interactive=False, lines=12)

            refresh_btn = gr.Button("Refresh Data")
            
            def update_dashboard():
                status, rul, alert, count = self.get_current_status()
                plot_fig = self.get_plot_figure()
                recommendations = self.get_recommendations()
                return status, rul, alert, count, plot_fig, recommendations
            
            demo.load(
                fn=update_dashboard,
                inputs=None,
                outputs=[status_box, rul_box, alert_box, data_count, plot, recommendation_box],
                every=1
            )
            refresh_btn.click(
                fn=update_dashboard,
                inputs=None,
                outputs=[status_box, rul_box, alert_box, data_count, plot, recommendation_box]
            )
        
        gradio_thread = threading.Thread(target=demo.launch, kwargs={
            'server_name': '0.0.0.0',
            'server_port': 7860,
            'share': False,
            'show_error': True,
            'enable_queue': True
        })
        gradio_thread.daemon = True
        gradio_thread.start()
        
        self.get_logger().info("Gradio interface started at http://localhost:7860")

def main(args=None):
    rclpy.init(args=args)
    node = ROS2RESTNode()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            if time.time() - node.last_update > 0.5:
                node.update_plot()
                node.last_update = time.time()
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        node.destroy_node()
        rclpy.shutdown()
        plt.close('all')

if __name__ == '__main__':
    main()

