import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import numpy as np

class HISimulationNode(Node):
    def __init__(self):
        super().__init__('hi_simulation_node')

        self.t = 0
        self.start_hi = 1.0
        final_hi = 0.1

        dataset_size = 2486
        window_size = 20
        nb_predictions = dataset_size - window_size + 1  # glissement d'une ligne

        self.degradation_rate = -np.log(final_hi / self.start_hi) / nb_predictions

        self.subscription_done = self.create_subscription(
            Bool,
            'model_done',
            self.done_callback,
            10
        )

        self.publisher_hi = self.create_publisher(
            Float64,
            'hi_simulation_topic',
            10
        )

        self.get_logger().info(
            f"🚀 HISimulationNode démarré (rate={self.degradation_rate:.8f}, "
            f"{nb_predictions} étapes, HI final={final_hi})"
        )

    def done_callback(self, msg: Bool):
        if msg.data:
            hi_real = self.simulate_hi()
            msg_pub = Float64()
            msg_pub.data = hi_real
            self.publisher_hi.publish(msg_pub)
            self.get_logger().info(f"📢 HI simulé publié : {hi_real:.3f}")
            self.t += 1

    def simulate_hi(self):
        return float(self.start_hi * np.exp(-self.degradation_rate * self.t))


def main(args=None):
    rclpy.init(args=args)
    node = HISimulationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

