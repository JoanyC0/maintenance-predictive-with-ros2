import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Bool
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from scipy.ndimage import gaussian_filter1d

HI_THRESHOLD = 0.1  # critical HI threshold

class HIAnalyzerNode(Node):
    def __init__(self):
        super().__init__('hi_analyzer_node')

        self.hi_actual = None
        self.hi_predicted = None

        self.actual_hi = []
        self.pred_hi = []
        self.window_count = 0  # Counter for windows

        # Temps pour l'axe X (365 jours pour 2466 prédictions)
        self.times = []  # Axe des abscisses en jours
        self.time_per_window = 365 / 2466

        # Subscriptions
        self.sub_actual = self.create_subscription(
            Float64,
            'hi_simulation_topic',
            self.callback_actual,
            10)

        self.sub_predicted = self.create_subscription(
            Float64,
            'hi_predit_topic',
            self.callback_predicted,
            10)

        # Publishers
        self.publisher_diff = self.create_publisher(Float64, 'hi_analysis', 10)
        self.publisher_rul = self.create_publisher(Float64, 'rul_estimate_topic', 10)
        self.publisher_alert = self.create_publisher(Bool, 'maintenance_alert_topic', 10)

        self.get_logger().info('🔍 HI analysis node with full history graph + RUL started.')

        self.setup_plot()

        # Lignes verticales pour zones importantes
        self.warning_line = None
        self.threshold_line = None
        self.warning_crossed = False  # flag pour éviter plusieurs lignes
        self.threshold_crossed = False

    def callback_actual(self, msg):
        self.hi_actual = msg.data
        # pas d'incrément ici → juste mise à jour

    def callback_predicted(self, msg):
        self.hi_predicted = msg.data
        self.try_compare()  # incrément uniquement quand une prédiction arrive

    def try_compare(self):
        if self.hi_actual is None or self.hi_predicted is None:
            return

        diff = abs(self.hi_actual - self.hi_predicted)
        self.get_logger().info(
            f'📊 HI comparison: Actual={self.hi_actual:.3f} | Predicted={self.hi_predicted:.3f} | Difference={diff:.3f}'
        )

        # Publish difference
        msg = Float64()
        msg.data = diff
        self.publisher_diff.publish(msg)

        # ---- RUL calculation ----
        RUL_estimate = max(0.0, (self.hi_predicted - HI_THRESHOLD) / max(self.hi_predicted, 1e-6))
        msg_rul = Float64()
        msg_rul.data = RUL_estimate
        self.publisher_rul.publish(msg_rul)

        self.get_logger().info(f'⏳ Estimated RUL: {RUL_estimate:.3f}')

        # ---- Alert detection ----
        alert = Bool()
        alert.data = (RUL_estimate <= 0.7)
        if alert.data:
            self.get_logger().warn("⚠️ Maintenance alert: RUL ≤ 0.7")
        self.publisher_alert.publish(alert)
        
        alert.data = (RUL_estimate <= 0.5)
        if alert.data:
            self.get_logger().warn("🛑 Immediate maintenance required: RUL ≤ 0.5")
        self.publisher_alert.publish(alert)

        # ---- Update history (1 seul incrément par prédiction) ----
        self.times.append(self.window_count * self.time_per_window)  # Temps en jours
        self.window_count += 1
        self.actual_hi.append(self.hi_actual)
        self.pred_hi.append(self.hi_predicted)

        # ---- Apply Gaussian smoothing ----
        if len(self.pred_hi) > 3:
            self.pred_hi = list(gaussian_filter1d(self.pred_hi, sigma=3))
        if len(self.actual_hi) > 3:
            self.actual_hi = list(gaussian_filter1d(self.actual_hi, sigma=3))
        
    def setup_plot(self):
        self.fig, self.ax = plt.subplots()
        self.ax.set_title("📈 Health Index Analysis")
        self.ax.set_xlabel("Time [days]")  # Axe X en jours
        self.ax.set_ylabel("HI")
        self.ax.set_ylim(-0.1, 1.1)

        self.line_actual, = self.ax.plot([], [], label='NormalDegradation HI', color='blue', linewidth=2.5)
        self.line_pred, = self.ax.plot([], [], label='Predicted HI', color='green', linewidth=2.5)

        # Colored zones
        self.ax.axhspan(0.7, 1.1, facecolor='white', alpha=0.1)
        self.ax.axhspan(0.3, 0.7, facecolor='white', alpha=0.1)
        self.ax.axhspan(-0.1, 0.3, facecolor='white', alpha=0.1)

        # Zone labels
        self.ax.text(0.99, 0.85, "✅ Good condition", ha='right', va='center', fontsize=12, color='green', alpha=0.9, transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.5, "⚠️ Warning", ha='right', va='center', fontsize=12, color='orange', alpha=0.9, transform=self.ax.get_yaxis_transform())
        self.ax.text(0.99, 0.15, "🛑 Imminent failure", ha='right', va='center', fontsize=12, color='red', alpha=0.9, transform=self.ax.get_yaxis_transform())

        # HI threshold line
        self.ax.axhline(HI_THRESHOLD, color='red', linestyle='--', linewidth=2, label=f'HI Threshold')

        # HI status text
        self.status_text = self.ax.text(
            0.01, -0.12, "", transform=self.ax.transAxes,
            ha='left', fontsize=13, fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.9, boxstyle='round,pad=0.3')
        )

        self.ax.legend(loc='upper left')
        self.fig.subplots_adjust(bottom=0.25)
        self.ani = animation.FuncAnimation(self.fig, self.update_plot, interval=500)
        plt.tight_layout()
        plt.show(block=False)

    def update_plot(self, frame):
        if self.times:
            self.line_actual.set_data(self.times, self.actual_hi)
            self.line_pred.set_data(self.times, self.pred_hi)
            self.ax.set_xlim(0, max(self.times) + self.time_per_window)

        # ---- HI status ----
        if self.pred_hi:
            last_pred = self.pred_hi[-1]
            last_time = self.times[-1]

            # Status label
            if last_pred > 0.7:
                label = "✅ Good condition"
                color = "green"
            elif last_pred > 0.3:
                label = "⚠️ Warning"
                color = "orange"
            else:
                label = "🛑 Imminent failure"
                color = "red"
            self.status_text.set_text(label)
            self.status_text.set_color(color)

            # ---- Vertical lines for first entry ----
            if (last_pred <= 0.5) and not self.warning_crossed:
                self.warning_line = self.ax.axvline(last_time, color='black', linestyle='--', linewidth=2, label='Warning entry')
                self.warning_crossed = True

            if (last_pred <= HI_THRESHOLD) and not self.threshold_crossed:
                self.threshold_line = self.ax.axvline(last_time, color='black', linestyle='--', linewidth=2, label='HI Threshold')
                self.threshold_crossed = True

        return self.line_actual, self.line_pred, self.status_text

def main(args=None):
    rclpy.init(args=args)
    node = HIAnalyzerNode()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            plt.pause(0.01)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

